#!/bin/bash

LIB_PATH="/app/lib/*"
CLASSPATH="${LIB_PATH}"
