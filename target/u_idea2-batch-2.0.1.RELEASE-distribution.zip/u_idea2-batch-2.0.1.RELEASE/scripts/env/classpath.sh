#!/bin/bash

LIB_PATH="lib/*"
CLASSPATH="${LIB_PATH}"
