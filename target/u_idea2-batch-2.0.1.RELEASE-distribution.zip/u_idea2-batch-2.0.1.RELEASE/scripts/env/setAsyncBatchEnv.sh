#!/bin/bash

BATCH_TERMINATE_FILE=/tmp/stop-async-batch-daemon

